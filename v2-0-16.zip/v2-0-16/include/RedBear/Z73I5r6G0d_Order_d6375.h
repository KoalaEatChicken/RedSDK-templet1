//
//  Z73I5r6G0d_Order_d6375.h
//  RedBear
//
//  Created by kfNdo50rI on 2018/3/5.
//  Copyright © 2018年 VCTJqi6mwWebA . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "AGuV4etMnF05_OpenMacros_V5MGtF.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSDictionary *qaIAelqCWfQOxzrNoZRPXybKaY;
@property(nonatomic, strong) NSDictionary *iuZtQvGhTdniY;
@property(nonatomic, strong) NSObject *ulxrQHWAubVqvYiDIayUm;
@property(nonatomic, copy) NSString *ekRTgoHyswcDESXatKxVOqMAr;
@property(nonatomic, strong) NSMutableArray *ukAFpSdeCHPTtWoEqGmLziY;
@property(nonatomic, strong) NSObject *xiQaEpzUjNKquJGOFBbgsftkYP;
@property(nonatomic, strong) NSObject *hmvVGAHWMxPrlqi;
@property(nonatomic, strong) NSArray *ndYxdvoqcDELwQOPeIyKTWVzl;
@property(nonatomic, strong) NSArray *vooTCSZLmKiUMsxjrfAJWycaebt;
@property(nonatomic, strong) NSMutableArray *zxmWhuAtTVyUxibDvfElqzcow;
@property(nonatomic, strong) NSArray *nvaHDQPIpBwqo;
@property(nonatomic, strong) NSObject *okyiDMoNxclPXsOIJvE;
@property(nonatomic, strong) NSNumber *yerpsuEfcFVSORTU;
@property(nonatomic, copy) NSString *zfhSaZfXulqtbgUV;
@property(nonatomic, strong) NSArray *lgJFjErLBUONDXHiCvzsfkIPMd;
@property(nonatomic, strong) NSArray *djKdYPGwQaqlRnTXikyxreHCu;
@property(nonatomic, strong) NSArray *fqaBzefLbFyrliuqRg;
@property(nonatomic, strong) NSMutableArray *ltXyHkSwxAeNEBGfamVZYJvLbDK;
@property(nonatomic, strong) NSDictionary *hteQCEBFDdJoSjUiym;
@property(nonatomic, strong) NSDictionary *edDBjNwAquGhFOPMbpE;
@property(nonatomic, strong) NSMutableDictionary *troxZYRtgjSkaeQIvwpETOHs;
@property(nonatomic, strong) NSArray *ztEBUoMmCYtiPgJGsN;
@property(nonatomic, strong) NSObject *wrPwxRXcrdHqlSLbG;
@property(nonatomic, copy) NSString *icxYaPnJcZoRqgyNAtsVDp;
@property(nonatomic, strong) NSDictionary *ctsMmPwKfNoxTDAvOGhgQjlkIr;
@property(nonatomic, strong) NSArray *ufZArUsVcBYyngxfqCdWNaluP;
@property(nonatomic, strong) NSObject *hkHBkwOuJmhra;
@property(nonatomic, strong) NSArray *nimxevQCpJPzXtNdAabg;
@property(nonatomic, copy) NSString *xfvKSoQYIuPF;
@property(nonatomic, strong) NSNumber *cuwmCFHzapPrRlSIbktW;
@property(nonatomic, strong) NSMutableArray *qaHcWOQguJtAZodIrTynzpN;
@property(nonatomic, strong) NSArray *epcpKRJwsftkxzTWCPVMgmBrL;
@property(nonatomic, strong) NSArray *mcJnawBRlxCDWeiYtMrNkU;
@property(nonatomic, strong) NSMutableDictionary *qxisgBlvaXHKnWNMcUAYCmwEb;
@property(nonatomic, strong) NSMutableArray *deAFBdKkTglR;
@property(nonatomic, strong) NSMutableDictionary *yxWJrjXaLCmGZISqHOgRldoVeu;
@property(nonatomic, strong) NSArray *plCwlNVodQfzKaWbgGRqHS;
@property(nonatomic, strong) NSMutableArray *bxRXxVoyuWHeKzZELOgJiSGaqt;
@property(nonatomic, strong) NSMutableArray *uqWgzdSLBsejDfrAVk;

/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
