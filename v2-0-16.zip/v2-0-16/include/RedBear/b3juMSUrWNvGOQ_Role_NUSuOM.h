//
//  b3juMSUrWNvGOQ_Role_NUSuOM.h
//  RedBear
//
//  Created by yD9Bkdpr8Gv1l on 2018/4/27.
//  Copyright © 2018年 azBFyRk6cV2pYLX . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "Yz8SkgoMWD0_OpenMacros_M0g8SDo.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSMutableDictionary *vsoWDQSRvyOAnpPjzINiC;
@property(nonatomic, strong) NSMutableDictionary *jiybWUvHrRQaoMZF;
@property(nonatomic, strong) NSMutableDictionary *yrIryBqheMbKdjkHwUlovATSs;
@property(nonatomic, strong) NSObject *artJvwraCBQHmKnNGScWkOE;
@property(nonatomic, strong) NSMutableDictionary *wySnhEvbYdOymwpZeCDiQNjKzB;
@property(nonatomic, strong) NSNumber *dsNjptWTkrFMzGUO;
@property(nonatomic, strong) NSNumber *edeIxJopOaiFvKdGsUbD;
@property(nonatomic, strong) NSObject *kytGzKqpCrQUwLPE;
@property(nonatomic, strong) NSMutableDictionary *zbPwRbdJykZNDsfAupiWvxISV;
@property(nonatomic, strong) NSNumber *kjplHyLYStknOAgbGCKdwzBoc;
@property(nonatomic, strong) NSObject *elhmAebUMLOZ;
@property(nonatomic, strong) NSMutableArray *xfNEPYSVzBKobDgx;
@property(nonatomic, strong) NSNumber *foiqUtGHjeDIhdWKs;
@property(nonatomic, strong) NSObject *hyShkbFsPigZGojvzepnYAJK;
@property(nonatomic, strong) NSDictionary *zgRbGmszKuZxT;
@property(nonatomic, strong) NSDictionary *svUQHBWJIqZYie;
@property(nonatomic, strong) NSMutableDictionary *fhORbcyhZgwpD;
@property(nonatomic, copy) NSString *zolxYcueZDEUhIfoCynr;
@property(nonatomic, strong) NSObject *cmxKkoBMtUJsOhDdSTe;
@property(nonatomic, strong) NSDictionary *piLOTCIoPDbBKvZXzynWNaemft;
@property(nonatomic, strong) NSMutableDictionary *rscyhkdCEgNWSeFLXBAzf;
@property(nonatomic, strong) NSMutableArray *aePWtblXhdUVramjOuqK;
@property(nonatomic, strong) NSObject *jbgniIXtMDPCVNw;
@property(nonatomic, strong) NSNumber *nsUPgeFrqVRClmSJBDY;
@property(nonatomic, strong) NSMutableDictionary *inrwqoLtmeaC;

/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
