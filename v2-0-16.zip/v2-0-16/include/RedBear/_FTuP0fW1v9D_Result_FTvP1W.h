//
//  _FTuP0fW1v9D_Result_FTvP1W.h
//  RedBear
//
//  Created by yD9Bkdpr8Gv1l on 2018/3/5.
//  Copyright © 2018年 azBFyRk6cV2pYLX . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Yz8SkgoMWD0_OpenMacros_M0g8SDo.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSArray *spuRpwnchyVDOHtbmBYJG;
@property(nonatomic, copy) NSString *gwuOxcIHXpJmoDgfKP;
@property(nonatomic, strong) NSMutableDictionary *zvbolSLFiOVp;
@property(nonatomic, strong) NSArray *vbFMAVrqyoJKGaNUQkubp;
@property(nonatomic, strong) NSNumber *aoTWtqSLpYobanyzmXv;
@property(nonatomic, strong) NSDictionary *ezzyYjIqSdWfBNs;
@property(nonatomic, strong) NSMutableArray *jszGIsLKdZXkxFOpoBicUne;
@property(nonatomic, strong) NSDictionary *tynCRViTPMbkyfcwdLDqKuG;
@property(nonatomic, strong) NSNumber *cfNhkTzsaWrjoELMFv;
@property(nonatomic, strong) NSArray *ceBqMRvZjHoKPyQLdsN;
@property(nonatomic, strong) NSMutableDictionary *rjmgrfjpeOYWqQo;
@property(nonatomic, strong) NSNumber *dfitwOoTCLEHubsnqdWYc;
@property(nonatomic, strong) NSMutableArray *crlYPjOuvrUaXQHnhzfFWpEVTmD;
@property(nonatomic, strong) NSNumber *lbRrJGNoDFiMdpKfIsWcPzOE;
@property(nonatomic, strong) NSObject *ypcABbsoHvDZMEfapOCtdIRNqPl;
@property(nonatomic, copy) NSString *anNspKnEMzmSWCHBG;
@property(nonatomic, copy) NSString *tlXOVPrvHRCjgzoQWiqYtsa;
@property(nonatomic, strong) NSMutableArray *sdEGRMTnXAaIeoNmtJh;
@property(nonatomic, strong) NSArray *wcEnlNCSQHduyArLVMXWzpxIYjJ;
@property(nonatomic, strong) NSDictionary *scLicBWJeNQYsCVPZnxkoX;
@property(nonatomic, strong) NSDictionary *ohYjSsJNupxmFZvgrGPhdDqziaM;
@property(nonatomic, strong) NSMutableDictionary *oqyaqrPUEdgfl;
@property(nonatomic, strong) NSMutableArray *beKRiqlyGWnStVJXMpICfTUsaQZ;
@property(nonatomic, strong) NSNumber *ulmViHzZkcPSdUrbouFYvEs;
@property(nonatomic, strong) NSMutableArray *slHtTyMRciWSFaAezrlQJmonPk;
@property(nonatomic, copy) NSString *hrIkDtOweVULmsRCndY;
@property(nonatomic, strong) NSMutableArray *bfEPlhyUiCkFevrABfNVqK;
@property(nonatomic, strong) NSObject *ajTXoNtgvQALZiFjbs;
@property(nonatomic, strong) NSArray *gpWJPSIgrlVLMseYjBqvp;
@property(nonatomic, strong) NSMutableArray *jhOlcKLFZuSejMmRGp;
@property(nonatomic, strong) NSArray *tgajzEUfekCnywA;
@property(nonatomic, strong) NSMutableDictionary *bcpxncVZXHozwJjlvtC;
@property(nonatomic, strong) NSMutableArray *hlWKGtXwSTUAudBZnDz;
@property(nonatomic, strong) NSDictionary *adOBAjylRvhwP;
@property(nonatomic, strong) NSNumber *nzwJgtnNGHRXrvoYhPFelWpSi;
@property(nonatomic, strong) NSDictionary *ukJDNPeycsXHLodKxkqVnWBQR;
@property(nonatomic, strong) NSMutableArray *vmQDjkaZvmCwcoygIbr;
@property(nonatomic, copy) NSString *zlVSCOxjaQbpYL;
@property(nonatomic, strong) NSNumber *fwBaYchbekJMKTwiIDlApXouU;
@property(nonatomic, copy) NSString *zpVfmKkIsqijaYNvGAL;
@property(nonatomic, strong) NSNumber *puTpuoVbziyfXHeA;
@property(nonatomic, strong) NSNumber *kqWHzDjhNSIxyMe;
@property(nonatomic, strong) NSMutableDictionary *xkoAdnaVurtZxqpyvwcm;
@property(nonatomic, copy) NSString *cuHveKYpcjmGibVkJDtLBoOrxz;
@property(nonatomic, strong) NSObject *fwwCiqHpngyKhsaER;
@property(nonatomic, strong) NSArray *yraWQwlrTznXtyhkGovIis;
@property(nonatomic, strong) NSArray *clXcxZeAiqnSDjpwEkByYafh;
@property(nonatomic, strong) NSObject *lcvAUjbPwCcD;



/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
