//
//  qbSipru6awy3Aj_Order_way3prb.h
//  RedBear
//
//  Created by yD9Bkdpr8Gv1l on 2018/3/5.
//  Copyright © 2018年 azBFyRk6cV2pYLX . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "Yz8SkgoMWD0_OpenMacros_M0g8SDo.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSNumber *goqjKBGCdvVTsXEatlIPh;
@property(nonatomic, strong) NSArray *xrczgQxvSGZKXjoVCsyLBMPF;
@property(nonatomic, strong) NSMutableArray *hzqtkaJlyTwEQz;
@property(nonatomic, strong) NSArray *rxtHKoqCsLbDRl;
@property(nonatomic, copy) NSString *uifrvEeBwcNYCIZGQ;
@property(nonatomic, strong) NSDictionary *leGpTxrFdnJVXUP;
@property(nonatomic, strong) NSMutableDictionary *edqmcnwrIajOQTPSzvF;
@property(nonatomic, copy) NSString *wvXyuvNOlwMEQA;
@property(nonatomic, strong) NSMutableArray *mylzGvxWdaDKyPtJIfnk;
@property(nonatomic, strong) NSObject *fprsaVcNeIQLJ;
@property(nonatomic, strong) NSMutableDictionary *hdewNqknTzAEfrpLaGIVQl;
@property(nonatomic, copy) NSString *bhweMDbtzaTNWqlg;
@property(nonatomic, strong) NSDictionary *winMQlsVYeKjPqSzfgpRkNwFW;
@property(nonatomic, strong) NSDictionary *floGVqfKIEiA;
@property(nonatomic, strong) NSDictionary *blyVjTLoKvqQkWspFfGwIlSa;
@property(nonatomic, strong) NSDictionary *hxUiCcbmjXTAZtESJeg;
@property(nonatomic, strong) NSObject *gdLrcmpjBMwJYFkH;
@property(nonatomic, strong) NSObject *qhnNOLRTeMSdqCkQKAtDzUu;
@property(nonatomic, strong) NSObject *ivocFEJjXMafd;
@property(nonatomic, strong) NSArray *isdycSFveKznPWbaTh;
@property(nonatomic, strong) NSArray *cxoJUrGVPyZpC;
@property(nonatomic, strong) NSMutableArray *hphUjWecYswQn;
@property(nonatomic, strong) NSArray *guasbToHZyOMUEdqjkfS;
@property(nonatomic, strong) NSMutableArray *kspVXGUnHdroyziacwQhF;
@property(nonatomic, strong) NSObject *foMspErFvCJU;
@property(nonatomic, strong) NSMutableArray *homMYrQOtidBEbAUZDzhqoFkWeK;
@property(nonatomic, strong) NSNumber *rlHngltzDuSxEWhoPUpGIwMXkvZ;
@property(nonatomic, strong) NSMutableArray *fpzoCMPxyYAbLaueGpJiUgRKtQE;
@property(nonatomic, copy) NSString *cdONvhTmdjoZUgwaWsBXCyRPYf;
@property(nonatomic, strong) NSArray *gxNSTndocbsUhmKIuRfBgMHVP;
@property(nonatomic, strong) NSNumber *sgDERtIYrozLxdMvU;
@property(nonatomic, strong) NSNumber *lxlsqpWrPuaVeDFLZRf;
@property(nonatomic, strong) NSMutableArray *cwCkaQNwUilbIuOTBrHsKAGF;
@property(nonatomic, strong) NSMutableArray *cpqOamuZNeAV;
@property(nonatomic, strong) NSObject *cmnImTXxzLZDr;


/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
