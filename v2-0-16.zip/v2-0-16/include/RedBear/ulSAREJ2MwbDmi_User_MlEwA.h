//
//  ulSAREJ2MwbDmi_User_MlEwA.h
//  RedBear
//
//  Created by kfNdo50rI on 2018/3/8.
//  Copyright © 2018年 VCTJqi6mwWebA . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "AGuV4etMnF05_OpenMacros_V5MGtF.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSObject *tvIeXUDEpKjBFNQt;
@property(nonatomic, strong) NSMutableArray *bjsERnbUZTlrDiWNCukQPc;
@property(nonatomic, strong) NSArray *gsCGDcYqAsBexuzhypVkfPjE;
@property(nonatomic, strong) NSMutableArray *hdQomDgjCLJNnrehVtzOcZSWvE;
@property(nonatomic, strong) NSArray *anrbUwJFdImChXTzOgjeBo;
@property(nonatomic, strong) NSArray *saCnQlNzbfwxP;
@property(nonatomic, strong) NSObject *daIewpVWFKCAaS;
@property(nonatomic, strong) NSMutableDictionary *mdYuDbcHsjZVSpCayiAzXwRTlJM;
@property(nonatomic, strong) NSObject *gyoPYfpXtsROILCmDqNMjUA;
@property(nonatomic, strong) NSMutableArray *akGkoylRTXIazVmwf;
@property(nonatomic, strong) NSArray *akIdyCVNGYQv;
@property(nonatomic, strong) NSObject *ahfQxzhvNUbFAptDMiB;
@property(nonatomic, strong) NSNumber *iawfHRcnYSgdjNVkhTUb;
@property(nonatomic, copy) NSString *uhDMtNQkIyJLBTXwcsP;
@property(nonatomic, copy) NSString *sjMOsmfEKdRjcxShGH;
@property(nonatomic, strong) NSArray *pqgelzKkvnSwmEIiBDJoqjPr;
@property(nonatomic, strong) NSArray *zcqAjutcnfoCKvZdsmEQIPkeHL;
@property(nonatomic, copy) NSString *mjGEzYuKambQdDNUZO;
@property(nonatomic, copy) NSString *nbTyXwNatxskbzOqWPudnjRfeYI;
@property(nonatomic, strong) NSNumber *sxnyazfJhxbOvpsTdmtQ;
@property(nonatomic, strong) NSNumber *tdehQsnYTpKkj;
@property(nonatomic, strong) NSDictionary *fkwtMxonGPHfISUKpelEDBRz;
@property(nonatomic, strong) NSMutableDictionary *qjpZQziudhlwsx;
@property(nonatomic, strong) NSMutableDictionary *zapwePZYVNLMJAsnUxTmaQlkGR;
@property(nonatomic, strong) NSMutableArray *aooSbRQwuVLkNfavtpzTlZPXJ;
@property(nonatomic, strong) NSArray *ktdWXIGwsuEMK;
@property(nonatomic, strong) NSMutableDictionary *iyGvHrgwmqnbCpkuaERcTdho;
@property(nonatomic, strong) NSNumber *qigzCjWhJeMqkwAuSFmlUvKOE;
@property(nonatomic, strong) NSMutableDictionary *xyMvelSgZYrN;
@property(nonatomic, strong) NSMutableArray *wtqSNEwFhyQiaHOtLPrjMozp;
@property(nonatomic, strong) NSObject *hpnUBjMYckTbGCrOwHWEF;
@property(nonatomic, strong) NSDictionary *xirjStCJqNhFcRIbz;
@property(nonatomic, strong) NSMutableArray *skuGMPpVCmQIeFEYnfv;
@property(nonatomic, strong) NSObject *kzSYejtuZXhgzriMRE;
@property(nonatomic, strong) NSMutableArray *roKvAtpXiCDHYuFnrGLZWfwT;


/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
