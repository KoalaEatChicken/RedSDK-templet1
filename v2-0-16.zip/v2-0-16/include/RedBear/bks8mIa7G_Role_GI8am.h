//
//  bks8mIa7G_Role_GI8am.h
//  RedBear
//
//  Created by kfNdo50rI on 2018/4/27.
//  Copyright © 2018年 VCTJqi6mwWebA . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "AGuV4etMnF05_OpenMacros_V5MGtF.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSArray *xoKOTbmwPMsdqZVvEFQkeR;
@property(nonatomic, strong) NSObject *jyDmXzOnUlEVLwdWFekp;
@property(nonatomic, strong) NSMutableDictionary *wcVSoNWMfQITDwnUpHXedmLZlzA;
@property(nonatomic, strong) NSDictionary *msaAlGyzLmSukKMX;
@property(nonatomic, strong) NSObject *nvqiLCZHJQbjDSTuPrgXKEVcYvR;
@property(nonatomic, strong) NSNumber *nlvLqWKOtnJCwBYhAgGHQDocxy;
@property(nonatomic, strong) NSObject *hcptoCPBMkncvZVTYDerIuOQbyE;
@property(nonatomic, strong) NSMutableDictionary *utQzduZgscxrk;
@property(nonatomic, strong) NSArray *jlsraEwRuQKDZdem;
@property(nonatomic, strong) NSArray *ayAnCNZldGDXOxuLzfTyIYroseg;
@property(nonatomic, strong) NSDictionary *dymJixgKFtzybGVpUunIlWfCE;
@property(nonatomic, strong) NSArray *zkRKpdDmVvLlGrMUZob;
@property(nonatomic, strong) NSMutableArray *usXLZvUDqKTuzgmjY;
@property(nonatomic, strong) NSMutableDictionary *mqBiackgpZFAMSY;
@property(nonatomic, strong) NSArray *reaActLoxhXWRdKGgVsQOkMBn;
@property(nonatomic, strong) NSDictionary *vkivUIBpSfYkawesjJguCE;
@property(nonatomic, strong) NSMutableArray *wpljstqEFkrnKMdfBbRoCY;
@property(nonatomic, copy) NSString *adWQAlKasDSTgpJtYz;
@property(nonatomic, strong) NSObject *dqFJrXQazPCL;
@property(nonatomic, strong) NSDictionary *ehOAIJdmoueGbCLinqlytYXjx;
@property(nonatomic, strong) NSNumber *fldNTxkVGLtpvswWO;
@property(nonatomic, strong) NSNumber *tyMwAirPgzCoScQIExs;
@property(nonatomic, strong) NSMutableArray *onjDOrAHdJmRbXzCaiV;
@property(nonatomic, strong) NSMutableDictionary *exGYcvPwWSJCLlUdVgqospXaO;
@property(nonatomic, strong) NSDictionary *fpEaGQcMiPSbsBJouvOnCDq;
@property(nonatomic, strong) NSDictionary *sjQahoXvejcrN;
@property(nonatomic, strong) NSMutableArray *burNILQzwpvWiltbuGVgDA;
@property(nonatomic, strong) NSArray *rmvetuoDKGVNEpXwYWcZLjPrl;
@property(nonatomic, strong) NSObject *lwYTmdrPnAkXLQMaGEScs;
@property(nonatomic, strong) NSDictionary *pisSJcBCoXDUTutrwEhFbfvLV;
@property(nonatomic, strong) NSNumber *bzlNMnPLCjqZpfdX;
@property(nonatomic, copy) NSString *xjYmsypbgNIlO;
@property(nonatomic, strong) NSDictionary *dcoGzqIgvhimls;
@property(nonatomic, strong) NSMutableArray *tsSpXFdCbDxmnTiZuyoqfs;
@property(nonatomic, strong) NSObject *uqjwRhOAzIaEnGc;



/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
