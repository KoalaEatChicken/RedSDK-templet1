//
//  wxZB80Yb3cW2JQXD_Result_cB83w.h
//  RedBear
//
//  Created by kfNdo50rI on 2018/3/5.
//  Copyright © 2018年 VCTJqi6mwWebA . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGuV4etMnF05_OpenMacros_V5MGtF.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSMutableArray *jhXoyZgWYcQE;
@property(nonatomic, strong) NSMutableArray *ikbeyAmFIOowlNkcRE;
@property(nonatomic, strong) NSNumber *ozXaWZMFqTyimDVf;
@property(nonatomic, strong) NSNumber *lcnyVGAsakjPUIFrREBtCJ;
@property(nonatomic, strong) NSNumber *avkatyhSPsxbEvAoMwlUu;
@property(nonatomic, strong) NSNumber *cvPfIuyJovVTdxZ;
@property(nonatomic, strong) NSMutableDictionary *scgMDOznqvIFhiUyXlmJBTj;
@property(nonatomic, strong) NSMutableDictionary *rgAQVJtsHvEagG;
@property(nonatomic, strong) NSMutableArray *qvyxgVKtjlLFGRBqeJ;
@property(nonatomic, strong) NSNumber *cpLTEGcfsuNwSmQAZnReyFCqbX;
@property(nonatomic, strong) NSArray *guxnpsTkJjMeRFAoISCmGqZwEX;
@property(nonatomic, strong) NSMutableDictionary *olhbJNQcRVpAqntW;
@property(nonatomic, strong) NSDictionary *peSVaxdYuqBtv;
@property(nonatomic, copy) NSString *hdhYDfpQlcnuAmKUEFHd;
@property(nonatomic, strong) NSMutableDictionary *pyHzjCtbBDRaiLgsEukYKZce;
@property(nonatomic, copy) NSString *ewlDBHsnhGvwXQTzCJqedItEV;
@property(nonatomic, strong) NSMutableArray *bjNhWQJZetwCAopEHsFOuGmrSKV;
@property(nonatomic, strong) NSMutableDictionary *zgJqIYSUAjxcBKGDiwVZHvPuEQ;
@property(nonatomic, strong) NSObject *prjSDgbBtcHxheCnTi;
@property(nonatomic, copy) NSString *jweuqPgRCXJrYBplQbViGZMTnSK;
@property(nonatomic, strong) NSArray *bpROpGFWYhxDPHiJjkM;
@property(nonatomic, strong) NSArray *niKTXENdjAxfZOSI;
@property(nonatomic, strong) NSMutableDictionary *wfMasHFiyWUIPocB;
@property(nonatomic, strong) NSNumber *ndzlUrRwFVOmkxQZiydgj;
@property(nonatomic, strong) NSDictionary *uzUOtqZaGXvfVRQbDji;
@property(nonatomic, strong) NSArray *tiiSOlcMjRZyeILTYUDbBzs;
@property(nonatomic, strong) NSMutableArray *fweSOVyMidaK;
@property(nonatomic, strong) NSMutableDictionary *jlFvkdAjgYPQofztqRUNeVEl;



/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
