#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKConfig XpEFSx6GBAUJ
#define KKOrder WxGaoXqW1ey6bAP
#define KKResult tBZ3XM_EGK8fcw
#define KKRole rbsrYwKxS2nz_oTiOHhQ
#define Koala P8zLWaB3_TVuEFr
#define KKUser qh1JUNCAFyd9xR
#define kgk_settleBillWithOrder kQcSPigeNbrwqmfx3
#define kgk_postRoleInfoWithModel vixf7O_zbBrFva
#define kgk_loginWithViewController XTv9oJmfi_jqdMWtknCA
#define kgk_demo_setPkver E2X5UyJAvIoHYqlF
#define kgk_initGameKitWithCompletionHandler NAzh2OeZlqj_MTVf6SN
#define kgk_switchAccounts Nf9NMe2Xih_kHqg6BWzEI
#define kgk_openLog H8_DoalAzWnUxk10jBs5

#endif
