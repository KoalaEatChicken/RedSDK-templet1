//
//  q8YX_ZTSdJR3rt9l_User_rXRqS.h
//  RedBear
//
//  Created by yD9Bkdpr8Gv1l on 2018/3/8.
//  Copyright © 2018年 azBFyRk6cV2pYLX . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "Yz8SkgoMWD0_OpenMacros_M0g8SDo.h"

@interface KKUser : NSObject

@property(nonatomic, copy) NSString *miYlSrmjFRGKiAebHQoOIZv;
@property(nonatomic, copy) NSString *fptaxqCMVcdeYAnLsGKH;
@property(nonatomic, strong) NSArray *taJrStNyxqKb;
@property(nonatomic, strong) NSObject *ltFfocOkhyuLvCGqjwbEnXt;
@property(nonatomic, strong) NSNumber *srLMTDGRvyIx;
@property(nonatomic, strong) NSNumber *rieNSBnJIfVcQuskxKZ;
@property(nonatomic, strong) NSDictionary *omNQSEkexDRFY;
@property(nonatomic, strong) NSNumber *zdFiQqOYNJyK;
@property(nonatomic, copy) NSString *xpUVMgGdWrFsZy;
@property(nonatomic, strong) NSNumber *yaouGSVwqAEQDFlKNpZUP;
@property(nonatomic, strong) NSMutableDictionary *jtCfJEmZeWoLngb;
@property(nonatomic, strong) NSDictionary *tovWGcSuFbRMJBjiLEq;
@property(nonatomic, strong) NSObject *vgbaGzKiePDIHdupFyh;
@property(nonatomic, strong) NSArray *kmjAnvYLgqPTNhoRczWH;
@property(nonatomic, strong) NSDictionary *uzPhletUfzkOLNFmsVwbjpdGnr;
@property(nonatomic, strong) NSMutableDictionary *teWCDpPwNEoTHQfinObsA;
@property(nonatomic, strong) NSNumber *rtInEOCdtsFkZwqVcuGxjlSfgo;
@property(nonatomic, strong) NSObject *nlnjvuOGHgUrNZKPVpy;
@property(nonatomic, strong) NSMutableArray *jcnObHUDxlmQB;
@property(nonatomic, strong) NSArray *grArfKvJHSGjyFoRuWzx;
@property(nonatomic, strong) NSArray *scAiOqetsZvTxRuQ;
@property(nonatomic, strong) NSObject *emJzMFWdUDNHBkZ;
@property(nonatomic, strong) NSMutableDictionary *mdvTPELMIQmKxBHNsWDorGCe;
@property(nonatomic, strong) NSArray *jcpAaRKDFYyLtglZrqUVmJ;
@property(nonatomic, strong) NSArray *htYPwCclRboLrFH;
@property(nonatomic, strong) NSObject *zehgakFbCVtELr;
@property(nonatomic, strong) NSMutableDictionary *zcwMdaHpxTYVQfiecXCEZRLO;
@property(nonatomic, strong) NSMutableArray *tqpOQBHJkFKzVqUgXZ;
@property(nonatomic, strong) NSMutableDictionary *qoHPEvKxBpkeQSDVX;
@property(nonatomic, strong) NSMutableArray *zamWXetIQJRgwjnFlqPTGvdUCDE;
@property(nonatomic, strong) NSMutableArray *gydAIwxoXHKlGBt;
@property(nonatomic, strong) NSObject *qbKDiJwfTYav;
@property(nonatomic, strong) NSMutableDictionary *ctGhjsLCJpbXtdzBArPqeoMUN;
@property(nonatomic, copy) NSString *kxiHMOkCRKWEJdhSQVbXeAxw;
@property(nonatomic, copy) NSString *gxbDwmhKaHGgz;
@property(nonatomic, strong) NSMutableArray *iwDEsYUugpixkPIrzTKZLNeSyOJ;
@property(nonatomic, strong) NSNumber *fazTUZtuliDrOvCQe;
@property(nonatomic, strong) NSObject *glGuOApZrBfxdznEoVw;




/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
