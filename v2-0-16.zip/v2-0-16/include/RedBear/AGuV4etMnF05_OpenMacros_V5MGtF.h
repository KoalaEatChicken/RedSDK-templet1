#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKConfig FcXO0MuAzyk
#define KKUser IViFIyPA1f7XhnqBSLmCQ
#define KKOrder XnIJ6_zS7ZurBHTkdc0R
#define KKRole cyjHtZiNsBeqxRGQg
#define KKResult oQydwM9Kqp5heRT6
#define Koala oG5dyNDF3lqwOBo1IsTR
#define kgk_settleBillWithOrder bJCUBzI8Zjd94hgME
#define kgk_initGameKitWithCompletionHandler MdgY4GyMqjWr8
#define kgk_loginWithViewController ZjYl8MicOunzxrIbUR0
#define kgk_postRoleInfoWithModel QatF6x75M1JzH
#define kgk_demo_setPkver PjgG1Nn2_XBkzatLVdRp6
#define kgk_openLog JjUkXMgme7P_EL
#define kgk_switchAccounts q1SFuPgbGVWU

#endif
