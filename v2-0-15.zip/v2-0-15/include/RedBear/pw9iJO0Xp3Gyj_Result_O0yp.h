//
//  pw9iJO0Xp3Gyj_Result_O0yp.h
//  RedBear
//
//  Created by Rd_3bwetSmnQF on 2018/3/5.
//  Copyright © 2018年 Wol3F48HiC . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JHCQVYh18oz2pc_OpenMacros_8o2CY.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSMutableArray *mvjwusXqliKBGovO;
@property(nonatomic, strong) NSArray *ufIFCMlEguyKw;
@property(nonatomic, strong) NSObject *ylNrOVnLshfPT;
@property(nonatomic, strong) NSObject *bcdAOXvRfZIqV;
@property(nonatomic, copy) NSString *ksDMkHcSrmqiLUsXou;
@property(nonatomic, strong) NSNumber *azqlhOeWyAIstMFkUHoCnxrDwK;
@property(nonatomic, copy) NSString *swaxEyKIqsWhw;
@property(nonatomic, strong) NSMutableArray *xfbtrvhkFAMxVHlaNQCnygZmY;
@property(nonatomic, strong) NSArray *delUhJYDWcOgVPnSywofQ;
@property(nonatomic, strong) NSArray *zvLNQfyHBCsSMqPRuZ;
@property(nonatomic, strong) NSNumber *imNzArMHpCoTJYtmRwPqaGLyhSi;
@property(nonatomic, strong) NSObject *xauahXKBsoiIfDytSFkrcGwn;
@property(nonatomic, copy) NSString *glecuHxPdUkDCpKGVBQlIgAnSr;
@property(nonatomic, strong) NSDictionary *duEdvJsPupqQM;
@property(nonatomic, strong) NSMutableArray *baHslQYRbOXmUfFyAk;
@property(nonatomic, strong) NSMutableArray *funTpoyRchjS;
@property(nonatomic, strong) NSObject *ybuKVGIzbFLZ;
@property(nonatomic, strong) NSObject *ltgAZaDEhobPfrixGsJdySNCU;
@property(nonatomic, strong) NSArray *qwSrGKvYCjMhtn;
@property(nonatomic, strong) NSDictionary *tlVSifUGBjnqWZH;
@property(nonatomic, strong) NSObject *lwHaMbWVkGZYsORJDiT;
@property(nonatomic, strong) NSObject *msJetXiAnESYKUxl;
@property(nonatomic, strong) NSObject *besHemnpRxPuCvkhyrBoSVfJqW;
@property(nonatomic, strong) NSMutableDictionary *edrRwYxlhnoyGOKMvUPemaQdtXB;
@property(nonatomic, strong) NSMutableArray *okDipjMdJLTvVGlmfQzrYt;
@property(nonatomic, strong) NSMutableArray *kgCiLvUOhmedq;
@property(nonatomic, strong) NSMutableDictionary *pzeSwTnkLoBGscdhvCYXbWQFDK;
@property(nonatomic, strong) NSMutableArray *xiCYUAofFzPhsnTS;
@property(nonatomic, strong) NSArray *gadLbanqOWsxhQSI;
@property(nonatomic, strong) NSMutableArray *dfsAiDbBLRVdJXlxZnHzkfoC;
@property(nonatomic, strong) NSDictionary *tsVscBnYzRCpJEPkaS;
@property(nonatomic, strong) NSArray *smIsTnRPDLoEKBmgybFA;




/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
