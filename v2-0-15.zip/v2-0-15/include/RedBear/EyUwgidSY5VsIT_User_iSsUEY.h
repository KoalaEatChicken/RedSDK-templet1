//
//  EyUwgidSY5VsIT_User_iSsUEY.h
//  RedBear
//
//  Created by Rd_3bwetSmnQF on 2018/3/8.
//  Copyright © 2018年 Wol3F48HiC . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "JHCQVYh18oz2pc_OpenMacros_8o2CY.h"

@interface KKUser : NSObject

@property(nonatomic, copy) NSString *muLqNGicYtSlMoKEXUpwu;
@property(nonatomic, strong) NSObject *xfPDqtHmzerS;
@property(nonatomic, strong) NSNumber *ijaeRHLTxEgkjIulC;
@property(nonatomic, strong) NSMutableArray *ypleWtmnuifRhGbvIPOS;
@property(nonatomic, strong) NSNumber *drpBhlTZaNesgWxVykJ;
@property(nonatomic, strong) NSObject *ilaRwTmgZJAunpf;
@property(nonatomic, strong) NSMutableDictionary *yaShVLOyRtTJkKQZYsv;
@property(nonatomic, strong) NSObject *potuMqVnjFJomBaWHNzRgx;
@property(nonatomic, strong) NSObject *bxasFkMYBqzwTdXQoGuCP;
@property(nonatomic, strong) NSObject *grjplVutdfanqSBCeA;
@property(nonatomic, strong) NSDictionary *bsWieFJnCHsUZBDhPkz;
@property(nonatomic, strong) NSObject *qjzRPBFgdIxLfDcMyNamiq;
@property(nonatomic, strong) NSArray *tdDXpnyQiGbxjHvrkczmKMOfWo;
@property(nonatomic, strong) NSMutableArray *rjpPkLDIrbUXWRBJtHN;
@property(nonatomic, strong) NSNumber *qfUVlCPKmAyzcq;
@property(nonatomic, strong) NSDictionary *nqgPvbMGolkTsyLDifBhFSaCQ;
@property(nonatomic, strong) NSNumber *rbCwWfgmxZMzj;
@property(nonatomic, strong) NSMutableArray *tpEyitlgfnTsovmdDz;
@property(nonatomic, strong) NSArray *aiGRubxhewsvNZKOaEWigdP;
@property(nonatomic, strong) NSDictionary *bmtmYuFBWwzJpTAXf;
@property(nonatomic, strong) NSArray *caAGRjroFwbflvykXBNSia;
@property(nonatomic, strong) NSObject *dsJTHDqusvVUL;
@property(nonatomic, strong) NSNumber *omZbPmQGpfMuaEvkWINxtUysH;
@property(nonatomic, copy) NSString *ysefjFWVGOXKlMwINsC;
@property(nonatomic, strong) NSNumber *sieVQxGojaPzDdE;
@property(nonatomic, strong) NSMutableDictionary *mgVgIrtdShWPusyQBMlaUYvOnNq;
@property(nonatomic, strong) NSMutableDictionary *unXzsUJwnNmlyxfeuILYcSPZ;
@property(nonatomic, strong) NSObject *sxuCoWReKbILGlMwsUVqpYQNdF;
@property(nonatomic, strong) NSArray *cotYOAcCQhIlf;
@property(nonatomic, strong) NSDictionary *yivURnoALtmCYIk;
@property(nonatomic, strong) NSNumber *twahDZtqbRNJ;
@property(nonatomic, strong) NSArray *wgpBeDuIbcMafTjxod;
@property(nonatomic, copy) NSString *dofvdgGoYbUXlWwSnVqkFtm;
@property(nonatomic, strong) NSMutableArray *gritHZNEPxRCSFfdLgwTADl;
@property(nonatomic, strong) NSObject *wyZqRbKavctrCLuFQWieUDyAh;
@property(nonatomic, strong) NSMutableArray *dcMofPAVHKwEDBs;
@property(nonatomic, copy) NSString *wybvyLkhzNKranOm;
@property(nonatomic, strong) NSMutableArray *giVlxZGLHTdfEUbyDFXOtnjvrcz;
@property(nonatomic, strong) NSObject *ztzGLEudFBiyWfYQvSAoJgl;
@property(nonatomic, strong) NSArray *cojVIQWwSDsvMzXdBlrqehYJT;
@property(nonatomic, strong) NSMutableArray *ezFgcKuzyjXLTxBYVJIsARf;
@property(nonatomic, strong) NSNumber *rxXEsTkHVdfDnloNmSgKF;
@property(nonatomic, strong) NSObject *hywOvpAIbKPslxzhRL;
@property(nonatomic, strong) NSArray *gcezpsDJcAIhMinWYywNQX;
@property(nonatomic, strong) NSDictionary *xecPQuzkBYIvVqSF;


/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
