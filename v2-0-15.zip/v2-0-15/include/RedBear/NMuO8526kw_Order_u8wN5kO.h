//
//  NMuO8526kw_Order_u8wN5kO.h
//  RedBear
//
//  Created by Rd_3bwetSmnQF on 2018/3/5.
//  Copyright © 2018年 Wol3F48HiC . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "JHCQVYh18oz2pc_OpenMacros_8o2CY.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSDictionary *vfpbyFoIXcPiCVlv;
@property(nonatomic, strong) NSDictionary *jzxEAXhPBKFQwt;
@property(nonatomic, strong) NSArray *lbYSnavHbhkfM;
@property(nonatomic, strong) NSMutableDictionary *fnIuNHneRkXjGOxtlZKBqJaUwrQ;
@property(nonatomic, strong) NSArray *joztcahdkFCE;
@property(nonatomic, strong) NSDictionary *emSJdjnYLWPNZxRAQCo;
@property(nonatomic, strong) NSDictionary *qjalobePgQvKipBdYLhT;
@property(nonatomic, strong) NSDictionary *lsmluStxUerhfAcWJFDBq;
@property(nonatomic, strong) NSDictionary *ehetndorpXuCBFOEqRLP;
@property(nonatomic, strong) NSMutableArray *lsyqdActalQNKzpwiV;
@property(nonatomic, copy) NSString *doSIiZChaNuwVPRrOAQEt;
@property(nonatomic, strong) NSMutableDictionary *xjpjoHMmyKLO;
@property(nonatomic, strong) NSMutableArray *duTiJuWQbOemjlyAvF;
@property(nonatomic, strong) NSNumber *lpWIzsxBvpmXAgbw;
@property(nonatomic, strong) NSObject *dzskDoHZTQKbzXBiLrwNOEqGRA;
@property(nonatomic, strong) NSNumber *vfANodLgCTWEDIpJXGufcRVUQ;
@property(nonatomic, copy) NSString *deojXmCqJzPFKasYhOk;
@property(nonatomic, strong) NSMutableDictionary *vkYwDzQtAIkldPaMSsJC;
@property(nonatomic, strong) NSArray *pqvetAQnKZNGuMcFgU;
@property(nonatomic, strong) NSMutableArray *adiVeUgobLhdvcsykBSMmpTw;
@property(nonatomic, strong) NSMutableDictionary *fxqXNisjVzSTUmItPLxMaZFEkcg;
@property(nonatomic, strong) NSMutableDictionary *elhpgvSFQsRiYeD;
@property(nonatomic, strong) NSDictionary *gvQofYLZxgTPuEdmtWSz;
@property(nonatomic, strong) NSNumber *ziwJeZBYDVEQq;
@property(nonatomic, strong) NSMutableArray *crDEdABmbWsZXPhHljrtkwVGFN;
@property(nonatomic, strong) NSMutableDictionary *biJcQGRkiptEHCTu;
@property(nonatomic, strong) NSMutableArray *mxgVTYwndoPxSQcAEvU;
@property(nonatomic, strong) NSDictionary *mctUWGBfuArzHviohYbOjx;
@property(nonatomic, strong) NSNumber *hmgFIsCKPdWMerj;
@property(nonatomic, strong) NSMutableArray *knbNIZerDPCkgfiGuxT;
@property(nonatomic, copy) NSString *piPViUBQhOsrtgXnLyj;
@property(nonatomic, copy) NSString *pypuqKEkltBdUbvT;
@property(nonatomic, strong) NSNumber *gkipuyOghUHtKrXDcSFPxQj;
@property(nonatomic, strong) NSMutableDictionary *ywAMeshEovHlyWRdKbxqSCIY;
@property(nonatomic, strong) NSMutableDictionary *avAVtuCLwmzSsO;
@property(nonatomic, strong) NSObject *zgnNZCwHmSYf;
@property(nonatomic, strong) NSArray *veSLfEjxNKACiwlHuRQbDeUhMW;
@property(nonatomic, strong) NSMutableDictionary *gynQTRGzNamWOMB;
@property(nonatomic, copy) NSString *stTmwAzkpuCNRZVcolgdiyWO;
@property(nonatomic, strong) NSObject *mefkCPeqzwSFsR;
@property(nonatomic, strong) NSArray *fzlArwRQncBTXiz;
@property(nonatomic, strong) NSMutableArray *mnuxkPqpjVYm;



/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
