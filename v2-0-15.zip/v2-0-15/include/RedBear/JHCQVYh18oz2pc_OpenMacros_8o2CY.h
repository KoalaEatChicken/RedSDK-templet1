#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKRole WJoz1DGpFigYfwEHa0L
#define Koala KG0dxAnlQCaNWhqHV_
#define KKConfig hyKYbHP_gAE1
#define KKResult T1JBf9GOwaTgxZ7
#define KKOrder _HwfzuVUFyg93amIxQ
#define KKUser jh9PgyiZau_6K5
#define kgk_postRoleInfoWithModel BXy9JE_4P8G2a
#define kgk_switchAccounts F4uCRbAhqHBXKtPzya
#define kgk_settleBillWithOrder RKJR17xCp2TgqE
#define kgk_loginWithViewController qHXbFlR6gkTno7yWYJ3uI
#define kgk_initGameKitWithCompletionHandler Phu1A_trqpx
#define kgk_openLog KayJuhYZzFCc
#define kgk_demo_setPkver nfXQwrZ3D46YeaRUs

#endif
