//
//  QT_9VAR8jKiJgk_Role_RAQ_j.h
//  RedBear
//
//  Created by Rd_3bwetSmnQF on 2018/4/27.
//  Copyright © 2018年 Wol3F48HiC . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "JHCQVYh18oz2pc_OpenMacros_8o2CY.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSNumber *kjsAKdJgORZzML;
@property(nonatomic, strong) NSDictionary *hrsxjOoERhCiSXk;
@property(nonatomic, strong) NSObject *alDeHKoiqJcZzCAFRWxbv;
@property(nonatomic, strong) NSMutableArray *agoBHaXDUdPKqRz;
@property(nonatomic, strong) NSDictionary *edlNgFjtypRVaIBhMYTPSZCco;
@property(nonatomic, strong) NSMutableArray *uezTRYFGANCSUxbWduO;
@property(nonatomic, strong) NSNumber *sjwrCkpvscgn;
@property(nonatomic, strong) NSDictionary *zpGXIToUqehWizHZ;
@property(nonatomic, strong) NSArray *uzyFUEkKWQPYZuoh;
@property(nonatomic, strong) NSDictionary *csYwNzfgUKXcbprBaRq;
@property(nonatomic, strong) NSObject *skObkXmWRDLfjp;
@property(nonatomic, strong) NSMutableDictionary *fxaxTAdDSujkQUWrpwBV;
@property(nonatomic, strong) NSMutableDictionary *jnOXPhTDvNxZgcqSwICKlMnLzf;
@property(nonatomic, strong) NSNumber *wvakuDfgzcYhExCKGIWVTiRmlFM;
@property(nonatomic, strong) NSObject *hgrGxObtTljNCowkM;
@property(nonatomic, strong) NSArray *qybfDvCUATMlhtNimJyV;
@property(nonatomic, strong) NSMutableArray *qjBdJICUQXbYAySVtaiP;
@property(nonatomic, strong) NSMutableDictionary *akOBHGVxTmKegnEpfzYMNaFr;
@property(nonatomic, strong) NSMutableDictionary *taEkeXJuDpfZAUPHigNhlwVvLC;
@property(nonatomic, copy) NSString *sovLRTwtUlFqID;
@property(nonatomic, strong) NSMutableDictionary *uiSzsLWqNoOhYAKXnBbyVRZw;
@property(nonatomic, strong) NSDictionary *shRoVpimZdnSasvJQzr;
@property(nonatomic, strong) NSDictionary *ydHyAUJBzhXjvDRWneYd;
@property(nonatomic, strong) NSMutableArray *cyJyrqNXcSawV;
@property(nonatomic, strong) NSDictionary *ztdoPBcHupSUknQ;
@property(nonatomic, strong) NSDictionary *xkLnkAvjmufQzwORKeb;
@property(nonatomic, copy) NSString *unRSlmwpfnIshuUVqoAGj;
@property(nonatomic, copy) NSString *cevzCNKtuifUcRVLhaH;
@property(nonatomic, strong) NSMutableArray *mbdIflwKtPMaqeYSoZUnH;
@property(nonatomic, strong) NSMutableArray *xsVlCmzshSYZwuUQTdtDLcv;
@property(nonatomic, strong) NSMutableArray *ycpCMktyqBfTjlFvQRNVJn;
@property(nonatomic, strong) NSMutableDictionary *crUYHANwhGEBtWTspujCI;
@property(nonatomic, strong) NSArray *lpgqcPJjlUTrxonH;
@property(nonatomic, copy) NSString *kzrkKBLNtogMSHC;
@property(nonatomic, strong) NSMutableDictionary *biyCaFjepdOUNIwBr;
@property(nonatomic, strong) NSMutableArray *yuOXwATZRrfExQqagpKLvYlSJbc;




/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
