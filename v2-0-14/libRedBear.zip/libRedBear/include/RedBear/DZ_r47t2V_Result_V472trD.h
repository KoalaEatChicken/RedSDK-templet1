//
//  DZ_r47t2V_Result_V472trD.h
//  RedBear
//
//  Created by fY83qPX1J9 on 2018/3/5.
//  Copyright © 2018年 msp45Dg9V_XmuANG . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "itBwI5vY107uGp_OpenMacros_uB0w.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSMutableArray *cvHoMLaOexSCFGj;
@property(nonatomic, strong) NSArray *rbzdQykgUBACl;
@property(nonatomic, strong) NSArray *nizdNtgGbfTvQi;
@property(nonatomic, strong) NSDictionary *gwnwWovbBYiXmEg;
@property(nonatomic, strong) NSMutableDictionary *saPMnvKAVHwefEp;
@property(nonatomic, strong) NSMutableDictionary *hiBXFkzdagEc;
@property(nonatomic, strong) NSArray *afeEFtQBugsdH;
@property(nonatomic, strong) NSObject *qcpLfeFQvVs;
@property(nonatomic, strong) NSDictionary *okEinZSfQI;
@property(nonatomic, strong) NSMutableDictionary *mpigzXomvbBMeH;
@property(nonatomic, strong) NSArray *wmHyzsTIwF;
@property(nonatomic, strong) NSMutableArray *rcJdrDGyaYEB;
@property(nonatomic, copy) NSString *aqsWGduRKAizBx;
@property(nonatomic, strong) NSObject *tdMhjAZtUpEK;
@property(nonatomic, strong) NSMutableArray *qksdltBScj;
@property(nonatomic, strong) NSNumber *yavtQZisgUa;

/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
