//
//  FIiXRrpulo7ONeA_Role_uNeRr.h
//  RedBear
//
//  Created by fY83qPX1J9 on 2018/4/27.
//  Copyright © 2018年 msp45Dg9V_XmuANG . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "itBwI5vY107uGp_OpenMacros_uB0w.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSArray *pztbjCnKzMDY;
@property(nonatomic, strong) NSMutableDictionary *gbAdqXhRCjDoSQ;
@property(nonatomic, strong) NSObject *flJCXmfHEbpI;
@property(nonatomic, strong) NSObject *cpBmIbXvcdJs;
@property(nonatomic, strong) NSMutableArray *cjAVFjbSeUw;
@property(nonatomic, strong) NSMutableArray *vxXRbQatqFf;


/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
