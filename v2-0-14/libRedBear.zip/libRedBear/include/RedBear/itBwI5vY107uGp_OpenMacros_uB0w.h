#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala c0LOI5Ff9RlkzWE
#define KKOrder f0NCP1c852VJoy
#define KKUser MbwyafuoAq9
#define KKRole pdR0TIQ_lep
#define KKResult _ZfeyXFPjCcmqlg1MG69W
#define KKConfig V20zAkc5vCqmJ
#define kgk_demo_setPkver ld3tv5HaIVr6sRMDq
#define kgk_postRoleInfoWithModel _kvULzNRpcB0u
#define kgk_loginWithViewController ix3oY8qDu0fSJdWpny
#define kgk_switchAccounts cs_x0locQJ3
#define kgk_initGameKitWithCompletionHandler WR0B3gINJD5GyLOWMASj
#define kgk_openLog F_Ll7VFhSg8GX
#define kgk_settleBillWithOrder iB_VRIZnuTCrwJj

#endif
