// 订单
#import <Foundation/Foundation.h>
#import "batterycubicOpenMacrosmotor.h"
@interface KKOrder : NSObject
/** 商品名称  */
@property(nonatomic, copy) NSString *subject;
/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;
/** 订单号  */
@property(nonatomic, copy) NSString *billno;
/** 内购id  */
@property(nonatomic, copy) NSString *iapId;
/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;
/** 服务器id */
@property(nonatomic, copy) NSString *serverid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setItalicFordatawindowmajorsymbolsunlock_cookie:(int)always_radixwizardshadowitalic; 
-(void)setGlanceplantportstabletcabinetcloselybitrate:(int)Presetflippedparityglance; 
-(void)setRejectpairedmicroeffectauthorstipple:(int)stretch_imagingconverttrellistraitsreject; 
-(void)setOptimumgallon_falloffpolling:(int)Sortingsafarishouldoptimum; 
-(void)setDesireDenaryfactorysplinecouplehaving:(NSString *)networklabelgesture_quickrandompassesdesire; 
-(void)setSafetyKcVzdevelopparsecscolor:(int)dTSCm_developeditorsafety; 
-(void)setPopupGramsformedlimithackerscaling:(NSString *)GYhfHstarteroptionsrollinpopup; 
-(void)setLibrarywarmupports_usuallybranch:(NSString *)Titlebeingrateseulerlibrary; 
-(void)setStarterGANVSdetectcommitghost:(int)kgrBC_modalpendingstarter; 
@end
