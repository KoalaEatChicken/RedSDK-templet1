//
//角色统计模型
#import <Foundation/Foundation.h>
#import "batterycubicOpenMacrosmotor.h"
@interface KKRole : NSObject
/** 区服id */
@property(nonatomic, copy) NSString *serverid;
/** 区服名称 */
@property(nonatomic, copy) NSString *servername;
/** 角色ID */
@property(nonatomic, copy) NSString *roleid;
/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;
/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
-(void)setWithinCaLpvitaltiming_edition:(int)DnTSwrapsdensitysyntaxvariantoceanwithin; 
-(void)setBuildpaperfanoutwebsitejSValuealign:(int)hGuS_defineswithin_bushelsbuild; 
-(void)setSpeakRespondstyleeditioninitial:(NSString *)periodsproducelongestpreloadspeak; 
-(void)setProvelYhH_lumensettlesolid:(NSString *)energycommon_deliversubtypeprove; 
-(void)setStridesNcSkgroundobscuremodalnodes:(NSString *)editbox_ranginginternconsistsimplystrides; 
-(void)setShellHeightpatchshowssortingfriends:(NSString *)fadeoutguided_azimuthsignedsubmitshell; 
-(void)setVowelgrantbladeowner:(int)Assetrunningillegalinnernucleusvowel; 
@end
