#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define KKResult JfoU6rQYTsM_VKDCv1gPH
#define Koala l1XYD_yCgLFchj7M
#define KKRole yXUiS4acJ9ArYRpm
#define KKUser pcVGtFgm0WE1UHn6PbI8
#define KKConfig XbAzgxXfDW59po
#define KKOrder yEB4i5xwGMVmPc2
#define kgk_settleBillWithOrder iywPBRDoANU
#define kgk_openLog v8n4yARPBzMF9wfi
#define kgk_postRoleInfoWithModel vDULFn9AIRa_Cj
#define kgk_initGameKitWithCompletionHandler Zfid_EysNUDCunKYjwr8
#define kgk_loginWithViewController G5gsEWFuYwAOGURdfP
#define kgk_switchAccounts TKMmH8NvfS7aETGikcW
#define kgk_demo_setPkver gMk1wRZbBiKlD2TF

#endif
