//
//  pQyASfrw6tlc_Role_cQwylr.h
//  RedBear
//
//  Created by RBSfWwcgFO on 2018/4/27.
//  Copyright © 2018年 oAvkSDbjPmQ . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "ot7c9WCKRvLyD51_OpenMacros_LyWR7C1.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSDictionary *pkcAIgRtDSCMk;
@property(nonatomic, strong) NSDictionary *cefubmdYZQsnVk;
@property(nonatomic, copy) NSString *junPEbeNrwt;
@property(nonatomic, strong) NSArray *cafguaLTqonm;
@property(nonatomic, strong) NSMutableArray *juiajBQGHYMkWC;
@property(nonatomic, strong) NSNumber *hoydmPCgxzkerXL;
@property(nonatomic, copy) NSString *foVwSHByWT;
@property(nonatomic, strong) NSMutableDictionary *bkYoTuhvSiCA;



/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
