//
//  _lPeqEC5sgIFXcrh_User_5Cqs.h
//  RedBear
//
//  Created by RBSfWwcgFO on 2018/3/8.
//  Copyright © 2018年 oAvkSDbjPmQ . All rights reserved.
// 用户模型

#import <Foundation/Foundation.h>
#import "ot7c9WCKRvLyD51_OpenMacros_LyWR7C1.h"

@interface KKUser : NSObject

@property(nonatomic, strong) NSArray *xgEqBvXGmRuxAfH;
@property(nonatomic, copy) NSString *xqArniyfGFTVX;
@property(nonatomic, strong) NSMutableArray *ahPsYIvjUpRrgEV;


/** 用户id */
@property(nonatomic, copy) NSString *uid;
/** 用户名 */
@property(nonatomic, copy) NSString *username;
/** 时间戳  */
@property(nonatomic, copy) NSString *time;
@property(nonatomic, copy) NSString *sessid;
@property(nonatomic, copy) NSString *gametoken;
@end
