//
//  j_sY09vrzg2cM5UA_Order_jvrUM.h
//  RedBear
//
//  Created by RBSfWwcgFO on 2018/3/5.
//  Copyright © 2018年 oAvkSDbjPmQ . All rights reserved.
// 订单

#import <Foundation/Foundation.h>
#import "ot7c9WCKRvLyD51_OpenMacros_LyWR7C1.h"

@interface KKOrder : NSObject

@property(nonatomic, strong) NSArray *lhTUNyCbGizOMcs;
@property(nonatomic, strong) NSObject *wpNqkOmDtvu;
@property(nonatomic, strong) NSNumber *osESoMYrwlmLkjZ;
@property(nonatomic, strong) NSArray *ufqpGtYsMmg;
@property(nonatomic, strong) NSObject *udRJHNpZTVWf;
@property(nonatomic, strong) NSArray *aejFgCqGvebklBK;
@property(nonatomic, strong) NSMutableArray *jezJxXrvEe;
@property(nonatomic, strong) NSDictionary *upaeYndWhZ;
@property(nonatomic, strong) NSNumber *yjLpMjwmHUVCWso;
@property(nonatomic, strong) NSObject *intRgvoDjCJw;
@property(nonatomic, strong) NSArray *kumniRMjBIQbEkt;
@property(nonatomic, strong) NSMutableArray *femUngaXkepjNF;
@property(nonatomic, strong) NSArray *btsqLnGYxbJaXE;
@property(nonatomic, strong) NSArray *pliMflKmACrWej;
@property(nonatomic, strong) NSArray *swTrYjzngX;

/** 商品名称  */
@property(nonatomic, copy) NSString *subject;

/** 金额（单位元）  */
@property(nonatomic, copy) NSString *amount;

/** 订单号  */
@property(nonatomic, copy) NSString *billno;

/** 内购id  */
@property(nonatomic, copy) NSString *iapId;

/** 额外信息  */
@property(nonatomic, copy) NSString *extrainfo;

/** 服务器id */
@property(nonatomic, copy) NSString *serverid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;

@end
